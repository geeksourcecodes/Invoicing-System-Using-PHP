<div class="row pdocrud-one-page-container" data-action="reload">
    <div class="col-sm-6">
        <?php echo $form;?>
    </div>
    <div class="col-sm-6">
        <?php echo $crud; ?>
    </div>
</div>